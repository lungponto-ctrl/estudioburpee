import os
from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'estudio_burpee_secret_key_2026'

# Mock Data
DATA = {
    "info": {
        "nome": "Estúdio Burpee",
        "telefone": "(31) 99157-8409",
        "endereco": "Avenida Imbiruçu, 65 - Bairro Petrolândia, Contagem - MG",
        "cep": "32.073-000"
    },
    "professores": [
        {"id": 1, "nome": "Carlos Silva", "telefone": "(31) 98888-1111", "especialidade": "Treino Funcional & Calistenia"},
        {"id": 2, "nome": "Juliana Costa", "telefone": "(31) 97777-2222", "especialidade": "Musculação & Reabilitação"}
    ],
    "alunos": [
        {
            "id": 1,
            "nome": "Lucas Almeida",
            "telefone": "(31) 99999-3333",
            "endereco": "Rua das Flores, 123",
            "data_nascimento": "1995-06-15",
            "frequencia": "3x por semana",
            "vencimento_mensalidade": (datetime.now() + timedelta(days=5)).strftime("%Y-%m-%d"),
            "usuario": "lucas",
            "senha": "123",
            "ficha": [
                {"exercicio": "Kettlebell Swing", "series": "4x15", "descanso": "45s"},
                {"exercicio": "Agachamento Livre", "series": "4x12", "descanso": "60s"},
                {"exercicio": "Burpees", "series": "3x20", "descanso": "30s"}
            ],
            "avaliacao": {"peso": "78kg", "altura": "1.75m", "gordura": "14%", "meta": "Emagrecimento e Condicionamento"}
        }
    ],
    "posts": [
        {
            "id": 1,
            "aluno": "Lucas Almeida",
            "legenda": "Mais um treino funcional pago no Estúdio Burpee! 💪🔥",
            "midia_url": "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80",
            "tipo": "imagem",
            "curtidas": 12,
            "data": "Hoje"
        }
    ]
}

@app.route('/')
def index():
    return render_template('index.html', info=DATA["info"], posts=DATA["posts"])

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        tipo = request.form.get('tipo')
        usuario = request.form.get('usuario')
        senha = request.form.get('senha')
        
        if tipo == 'admin' and usuario == 'admin' and senha == 'admin':
            session['user'] = {'role': 'admin', 'nome': 'Administrador'}
            return redirect(url_for('admin_dashboard'))
        elif tipo == 'aluno':
            aluno = next((a for a in DATA['alunos'] if a['usuario'] == usuario and a['senha'] == senha), None)
            if aluno:
                session['user'] = {'role': 'aluno', 'data': aluno}
                return redirect(url_for('aluno_dashboard'))
    return render_template('login.html', info=DATA["info"])

@app.route('/admin')
def admin_dashboard():
    if session.get('user', {}).get('role') != 'admin':
        return redirect(url_for('login'))
    return render_template('admin.html', info=DATA["info"], professores=DATA["professores"], alunos=DATA["alunos"])

@app.route('/aluno')
def aluno_dashboard():
    user = session.get('user')
    if not user or user.get('role') != 'aluno':
        return redirect(url_for('login'))
    
    aluno = user['data']
    venc_date = datetime.strptime(aluno['vencimento_mensalidade'], "%Y-%m-%d")
    dias_restantes = (venc_date - datetime.now()).days
    alerta_vencimento = dias_restantes <= 7
    
    return render_template('aluno.html', info=DATA["info"], aluno=aluno, dias_restantes=dias_restantes, alerta=alerta_vencimento, posts=DATA["posts"])

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
